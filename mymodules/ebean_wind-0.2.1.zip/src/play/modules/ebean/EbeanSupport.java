package play.modules.ebean;

/**
 * User: Freewind
 * Date: 13-1-16
 * Time: 下午8:42
 */
public interface EbeanSupport {
}
