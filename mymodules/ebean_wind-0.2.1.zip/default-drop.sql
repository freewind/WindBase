drop table if exists questions;
